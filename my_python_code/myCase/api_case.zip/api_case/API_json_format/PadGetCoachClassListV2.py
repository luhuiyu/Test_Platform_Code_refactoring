import inspect_API.interface.Basic_information

standard_json={
    "beginDate": inspect_API.interface.Basic_information.beginDate,
    "coachId": inspect_API.interface.Basic_information.coachId,
    "listRange": inspect_API.interface.Basic_information.listRange,
    "listSort": inspect_API.interface.Basic_information.listSort,
    "pageIndex": inspect_API.interface.Basic_information.pageIndex,
    "pageSize": inspect_API.interface.Basic_information.pageSize
  }