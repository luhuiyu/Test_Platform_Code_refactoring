#专业版的
standard_json={
  "report": {
    "frontUserPhotoInfo": {
      "partOffsetList": [
        {
          "offsetCode": "F0502",
          "offsetName": "外八脚",
          "partCode": "F05",
          "partName": "足部"
        }
      ],
      "photoData": "",
      "photoMemo": "",
      "photoUrl": ""
    },
    "physicalType": 0,
    "sideUserPhotoInfo": {
      "partOffsetList": [
        {
          "offsetCode": "S0401",
          "offsetName": "前凸",
          "partCode": "S04",
          "partName": "腰椎"
        }
      ],
      "photoData": "",
      "photoMemo": "",
      "photoUrl": ""
    },
    "submitReport": 0,
    "userBaseInfo": {
      "age": 36,
      "armLeft": 36,
      "armRight": 33,
      "chestCircumference": 36,
      "gender": "男",
      "height": 188,
      "hipCircumference": 36,
      "legLeft": 33,
      "legRight": 33,
      "name": "5522",
      "personType": "普通人",
      "waistCircumference": 66
    },
    "userInjureInfo": {
      "userHurtInfoList": [

      ],
      "userInjureHistoryList": [
        "消化系统疾病"
      ]
    },
    "userWeightInfo": {
      "bendingCount": 33,
      "bmi": 17.2,
      "bmr": 1728.7,
      "bones": 2.9,
      "bonesRatio": 4.8,
      "entrailsFat": 2,
      "fat": 22.4,
      "fatRatio": 6.7,
      "muscle": 53.8,
      "muscleRatio": 88.5,
      "squatCount": 33,
      "water": 37.1,
      "waterRatio": 61.1,
      "weight": 60.8
    }
  },
  "userCode": 100230
}