from my_python_code.myCase.api_case.interface.login_args import login
import my_python_code.myCase.api_case.interface.Basic_information
import  my_python_code.myCase.api_case.interface.接口记录
import requests
import logging.handlers
import time
import os
from my_python_code.basic_configuration.configuration_file import *

if not os.path.exists( 'log_Warehouse'):
        os.makedirs('log_Warehouse')
LOG_FILE = 'log_Warehouse/'+time.strftime('%Y_%m_%d %H_%M_%S__',time.localtime(time.time()))+'testlog.log'
handler = logging.handlers.RotatingFileHandler(LOG_FILE, maxBytes=1024*1024 * 1024, backupCount=5)  # 实例化handler
fmt = '[ %(asctime)s - %(filename)s:%(lineno)s - %(levelname)s ] [%(funcName)s]   %(message)s'
formatter = logging.Formatter(fmt)  # 实例化formatter
handler.setFormatter(formatter)  # 为handler添加formatter
handler.setLevel(logging.INFO)
def put_log():
    global handler
    return handler
def get_error(test_case):  #装饰器，
      def wrapper(*args, **kw):
          try:
              return test_case(*args, **kw)
          except  Exception as e:
              return {"result": -1, "error_info": '\'' + str(e) + '\''}

      return wrapper

class Basics_case():
  def __init__(self):  #基本设置
    self.url = my_python_code.myCase.api_case.interface.Basic_information.main_url  # 主地址，可以切换现网 测试网或者不同app的
    self.client = requests.session()    #定义一个长链接
    self.db=kk_test.db  #赋值数据库
    self.cursor=kk_test.cursor
    #self.logger = logging.getLogger('Basics_case')  #不填就捕获所有的log
    self.logger = logging.getLogger()
    self.logger.addHandler(handler)  # 为logger添加handler
    self.logger.setLevel(logging.INFO)
   # print(id(self.logger))
    try:    #如果有给json就使用给的json，没有就给一个默认的
         if  standard_json :
             pass
    except NameError:
        try:
            exec('import my_python_code.myCase.api_case.API_json_format.'+self.API_name)
            self.standard_json=eval('my_python_code.myCase.api_case.API_json_format.'+self.API_name+'.standard_json')  # 获取最新的json格式
        except:
            pass
  def API_url(self):   # 拼接完整的url
    API_url = self.url + self.API_name
    return API_url


  def test_case(self,json=None):  #这个是为了简单的验证接口通不通
    if json:
        self.logger.info(json)
    else:
      json=self.standard_json
    login(self.client)  #登录
    post_url=self.client.post(url=self.API_url(),json=json)
    self.logger.info(post_url.status_code)
    return post_url

  def compare(self,expected_result,json=None):  #对比结果 统一调用获取最后结果的时候都用他
      operation_resultself=self.test_case(self,json)
      if operation_resultself.status_code==expected_result:
          return 1
      else:
        return 0



if __name__=='__main__':
    example=Basics_case()
    print(example.test_case())