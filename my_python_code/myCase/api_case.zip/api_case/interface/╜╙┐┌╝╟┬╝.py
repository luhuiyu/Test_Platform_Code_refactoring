#!/usr/bin/env python
#coding=utf-8

main_url='http://test.kuaikuaikeji.com/kcas/'
h5_json_rul='http://192.168.41.41/KKNewReport/PadGetUUIDUserReportV3?i='
登录='PadCoachLoginV2'
获取课程列表='PadGetCoachClassListV2'
获取资源列表='PadGetResourceListV2'
记录教练操作='PadLogV2'
更新极光推送信息='PadUploadChannelIDV2'
获取开课的状态='PadStartClassV2'
获取当前课程的小节信息='PadGetCourseDetailV2'
获取当前班级的学员信息='PadGetCoachClassInfoV2'
获取当前班级的签到信息='PadGetCoachClassCheckinV2'
上传学员运动数据='PadUploadAllClassDataV2'
获取当前课程的报告列表='PadGetClassReportListV2'
私教课体测or专业课体测='PadUploadPhysicalReportV2'
