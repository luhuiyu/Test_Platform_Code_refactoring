#!/usr/bin/env python
#coding=utf-8
import my_python_code.myCase.api_case.interface.login_args
from imp import reload
import logging
logging.basicConfig(level=logging.INFO)
from my_python_code.myCase.api_case.interface.Basics_class import Basics_case
import my_python_code.myCase.api_case.interface.Basic_information
import  my_python_code.myCase.api_case.interface.接口记录
class API_case(Basics_case):
  def __init__(self):
    self.API_name =my_python_code.myCase.api_case.interface.接口记录.上传学员运动数据
    Basics_case.__init__(self)  #子类中含有__init__时，不会自动调用父类__init__，如需使用父类__init__中的变量，则需要在子类__init__中显式调用
  def test_case(self):
      client = self.client


if __name__=='__main__':
    example=API_case()
    print(example.test_case())