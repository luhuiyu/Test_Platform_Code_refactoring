#!/usr/bin/env python
#coding=utf-8
from my_python_code.myCase.api_case.interface.login_args import login
from imp import reload
import logging
logging.basicConfig(level=logging.INFO)
from my_python_code.myCase.api_case.interface.Basics_class import Basics_case,get_error
import my_python_code.myCase.api_case.interface.Basic_information
import  my_python_code.myCase.api_case.interface.接口记录
class API_case(Basics_case):
  def __init__(self):
    self.API_name =my_python_code.myCase.api_case.interface.接口记录.上传学员运动数据
    Basics_case.__init__(self)  #子类中含有__init__时，不会自动调用父类__init__，如需使用父类__init__中的变量，则需要在子类__init__中显式调用

  @get_error
  def test_case(self):
      client = self.client
      login( self.client)
      old_class_data=self.client.get("http://kkuserdata.oss-cn-beijing.aliyuncs.com/bodydata/b8605f95-a469-4f83-beda-52386b40eb19.txt")
      assert  old_class_data.status_code == 200 ,"获取class_data出错"
      #old_report_data=self.client.get()
      up_new_report=self.client.post(url=self.API_url(),data=old_class_data)
      print(up_new_report.status_code)
      assert  up_new_report.status_code == 200 ,"上传报告出错"

if __name__=='__main__':
    example=API_case()
    print(example.test_case())